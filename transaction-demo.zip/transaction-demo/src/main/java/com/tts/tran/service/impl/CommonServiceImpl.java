package com.tts.tran.service.impl;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tts.tran.domain.Address;
import com.tts.tran.domain.User;
import com.tts.tran.service.AddressService;
import com.tts.tran.service.CommonService;
import com.tts.tran.service.UserService;

@Service
public class CommonServiceImpl implements CommonService {

	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private UserService userService;

	@Autowired
	private AddressService addressService;

	
	@Transactional(propagation = Propagation.REQUIRED)
	@Override
	public void saveUserAddress() {

		User user = new User(1L, "Shiva");

		userService.saveUser(user);
		Address address = new Address(1L, "Delhi");
		try {
			addressService.saveAddress(address);
		} catch(Exception exception) {
			logger.error("Exception handelled !", exception);
		}
		
		
	}

}
