package com.tts.tran.service;

public interface CommonService {
	void saveUserAddress();
}
