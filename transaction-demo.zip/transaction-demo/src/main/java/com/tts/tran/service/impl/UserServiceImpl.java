package com.tts.tran.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tts.tran.domain.User;
import com.tts.tran.repository.UserRepository;
import com.tts.tran.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	
	@Transactional(propagation = Propagation.REQUIRED)
	@Override
	public void saveUser(User user) {
		userRepository.save(user);

	}

}
