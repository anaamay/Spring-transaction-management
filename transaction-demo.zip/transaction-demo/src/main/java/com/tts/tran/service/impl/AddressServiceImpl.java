package com.tts.tran.service.impl;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tts.tran.domain.Address;
import com.tts.tran.repository.AddressRepository;
import com.tts.tran.service.AddressService;

@Service
public class AddressServiceImpl implements AddressService {

	
	Logger logger = LoggerFactory.getLogger(AddressServiceImpl.class);
	
	@Autowired
	private AddressRepository addressRepository;

	
	@Transactional(propagation = Propagation.REQUIRED)
	@Override
	public Address saveAddress(Address address) {
		Address address2 =  addressRepository.save(address);
		int i=10/0;
		
		return address2;
	}

}
