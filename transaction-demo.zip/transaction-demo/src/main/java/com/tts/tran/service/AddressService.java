package com.tts.tran.service;

import com.tts.tran.domain.Address;

public interface AddressService {
	public Address saveAddress(Address address);
}
