package com.tts.tran.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tts.tran.service.CommonService;

@RestController
public class UserController {
	
	@Autowired
	private CommonService commonService;
	
	@GetMapping("/transaction")
	public String saveUserAddress() {
		commonService.saveUserAddress();
		
		return "Data saved!";
	}


}
